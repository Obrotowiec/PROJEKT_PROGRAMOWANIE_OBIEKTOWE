﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proj2
{
    public partial class CennikForm : Form
    {
        public CennikForm()
        {
            InitializeComponent();
        }

        private void CennikForm_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            label1.Font = new Font("Segoe Script", 15);
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.AutoSize = true;  // żeby rozmiar dopasował się do tekstu
            label1.TextAlign = ContentAlignment.MiddleLeft;
            label1.ForeColor = Color.White; // 👈 kolor tekstu

            label1.Text =
                "CENNIK BILETÓW\n\n" +
                "Rodzaj biletu         Normalny     Ulgowy\n" +
                "\n" +
                "Godzinny              40 zł        20 zł\n" +
                "Dwugodzinny           60 zł        30 zł\n" +
                "Czterogodzinny        90 zł        45 zł\n" +
                "Całodniowy           130 zł        65 zł\n" +
                "Tygodniowy           400 zł       200 zł";

            // Teraz wyśrodkuj label - po ustawieniu tekstu i AutoSize
            label1.Left = (this.ClientSize.Width - label1.Width) / 2;
            label1.Top = (this.ClientSize.Height - label1.Height) / 2;
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
