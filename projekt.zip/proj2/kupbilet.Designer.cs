﻿namespace proj2
{
    partial class Kupbilet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Kupbilet));
            radioButton3 = new RadioButton();
            radioButton4 = new RadioButton();
            radioButton5 = new RadioButton();
            radioButton1 = new RadioButton();
            radioButton6 = new RadioButton();
            numericUpDown1 = new NumericUpDown();
            button1 = new Button();
            radioButton2 = new RadioButton();
            ULGOWY = new RadioButton();
            panel1 = new Panel();
            panel2 = new Panel();
            textBox5 = new TextBox();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(31, 24);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(38, 19);
            radioButton3.TabIndex = 2;
            radioButton3.TabStop = true;
            radioButton3.Text = "1h";
            radioButton3.UseVisualStyleBackColor = true;
            radioButton3.CheckedChanged += radioButton3_CheckedChanged;
            // 
            // radioButton4
            // 
            radioButton4.AutoSize = true;
            radioButton4.Location = new Point(31, 49);
            radioButton4.Name = "radioButton4";
            radioButton4.Size = new Size(38, 19);
            radioButton4.TabIndex = 3;
            radioButton4.TabStop = true;
            radioButton4.Text = "2h";
            radioButton4.UseVisualStyleBackColor = true;
            radioButton4.CheckedChanged += radioButton4_CheckedChanged;
            // 
            // radioButton5
            // 
            radioButton5.AutoSize = true;
            radioButton5.Location = new Point(31, 74);
            radioButton5.Name = "radioButton5";
            radioButton5.Size = new Size(38, 19);
            radioButton5.TabIndex = 4;
            radioButton5.TabStop = true;
            radioButton5.Text = "4h";
            radioButton5.UseVisualStyleBackColor = true;
            radioButton5.CheckedChanged += radioButton5_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(31, 99);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(86, 19);
            radioButton1.TabIndex = 7;
            radioButton1.TabStop = true;
            radioButton1.Text = "całodniowy";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += radioButton1_CheckedChanged_1;
            // 
            // radioButton6
            // 
            radioButton6.AutoSize = true;
            radioButton6.Location = new Point(31, 124);
            radioButton6.Name = "radioButton6";
            radioButton6.Size = new Size(88, 19);
            radioButton6.TabIndex = 8;
            radioButton6.TabStop = true;
            radioButton6.Text = "tygodniowy";
            radioButton6.UseVisualStyleBackColor = true;
            radioButton6.CheckedChanged += radioButton6_CheckedChanged;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(435, 109);
            numericUpDown1.Maximum = new decimal(new int[] { 10, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(120, 23);
            numericUpDown1.TabIndex = 10;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 20F);
            button1.Location = new Point(96, 316);
            button1.Name = "button1";
            button1.Size = new Size(263, 66);
            button1.TabIndex = 11;
            button1.Text = "KUP KARNET";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(25, 47);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(91, 19);
            radioButton2.TabIndex = 1;
            radioButton2.TabStop = true;
            radioButton2.Text = "NORMALNY";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // ULGOWY
            // 
            ULGOWY.AutoSize = true;
            ULGOWY.Location = new Point(25, 22);
            ULGOWY.Name = "ULGOWY";
            ULGOWY.Size = new Size(74, 19);
            ULGOWY.TabIndex = 0;
            ULGOWY.TabStop = true;
            ULGOWY.Text = "ULGOWY";
            ULGOWY.UseVisualStyleBackColor = true;
            ULGOWY.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.Control;
            panel1.Controls.Add(radioButton2);
            panel1.Controls.Add(ULGOWY);
            panel1.Location = new Point(71, 109);
            panel1.Name = "panel1";
            panel1.Size = new Size(135, 87);
            panel1.TabIndex = 12;
            // 
            // panel2
            // 
            panel2.Controls.Add(radioButton3);
            panel2.Controls.Add(radioButton6);
            panel2.Controls.Add(radioButton1);
            panel2.Controls.Add(radioButton4);
            panel2.Controls.Add(radioButton5);
            panel2.Location = new Point(263, 103);
            panel2.Name = "panel2";
            panel2.Size = new Size(135, 169);
            panel2.TabIndex = 13;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(606, 109);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(112, 23);
            textBox5.TabIndex = 15;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // button2
            // 
            button2.Location = new Point(12, 415);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 16;
            button2.Text = "powrót";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-176, 82);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1143, 656);
            pictureBox1.TabIndex = 17;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F);
            label1.Location = new Point(71, 51);
            label1.Name = "label1";
            label1.Size = new Size(135, 28);
            label1.TabIndex = 18;
            label1.Text = "TYP KARNETU";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F);
            label2.Location = new Point(263, 51);
            label2.Name = "label2";
            label2.Size = new Size(150, 28);
            label2.TabIndex = 19;
            label2.Text = "CZAS TRWANIA";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F);
            label3.Location = new Point(463, 51);
            label3.Name = "label3";
            label3.Size = new Size(63, 28);
            label3.TabIndex = 20;
            label3.Text = "ILOŚĆ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15F);
            label4.Location = new Point(629, 51);
            label4.Name = "label4";
            label4.Size = new Size(62, 28);
            label4.TabIndex = 21;
            label4.Text = "CENA";
            // 
            // Kupbilet
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(textBox5);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(button1);
            Controls.Add(numericUpDown1);
            Controls.Add(pictureBox1);
            Name = "Kupbilet";
            Text = "kupbilet";
            Load += kupbilet_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private RadioButton radioButton3;
        private RadioButton radioButton4;
        private RadioButton radioButton5;
        private RadioButton radioButton1;
        private RadioButton radioButton6;
        private NumericUpDown numericUpDown1;
        private Button button1;
        private RadioButton radioButton2;
        private RadioButton ULGOWY;
        private Panel panel1;
        private Panel panel2;
        private TextBox textBox5;
        private Button button2;
        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}