﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proj2
{
    public partial class PlatnoscForm : Form
    {

        private Form1 form1Ref;

        public PlatnoscForm(Form1 form1)
        {
            InitializeComponent();
            form1Ref = form1;
        }

        private void PlatnoscForm_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;

            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 4000; // 4 sekundy
            timer.Tick += (s, args) =>
            {
                timer.Stop();

                // Ukryj wszystkie kontrolki oprócz labelDziekujemy
                foreach (Control ctrl in this.Controls)
                {
                    if (ctrl != label2)
                        ctrl.Visible = false;
                }

                // Pokaż napis
                label2.Visible = true;

                // Uruchom timer do automatycznego zamknięcia po 3 sekundach
                System.Windows.Forms.Timer closeTimer = new System.Windows.Forms.Timer();
                closeTimer.Interval = 3000; // 3 sekundy
                closeTimer.Tick += (cs, ce) =>
                {
                    closeTimer.Stop();
                    this.Hide();
                    form1Ref.Show(); // ← to pokazuje z powrotem Form1
                    this.Close();
                };
                closeTimer.Start();
            };
            timer.Start();



        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
