﻿namespace proj2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Kupbilet nowyFormularz = new Kupbilet(this);
            nowyFormularz.ShowDialog(); // otwiera nowe okno modalnie
            this.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide(); // Ukryj Form1
            CennikForm cennik = new CennikForm();
            cennik.ShowDialog(); // Pokaż okno cennika
            this.Show(); // Pokaż Form1 po zamknięciu CennikForm
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Paint += pictureBox1_Paint;

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            string tekst = "Góra Szczura";
            Font czcionka = new Font("Segoe Script", 48, FontStyle.Bold);
            Brush pedzel = Brushes.Black;

            // Możesz zmienić pozycję (np. środek obrazu)
            PointF pozycja = new PointF(129, 70);

            e.Graphics.DrawString(tekst, czcionka, pedzel, pozycja);
        }


    }
}
