﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace proj2
{
    public partial class Kupbilet : Form
    {
        private Form1 form1Ref;

        public Kupbilet(Form1 form1)
        {
            InitializeComponent();
            form1Ref = form1;
            AktualizujCene();
        }

        private void kupbilet_Load(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Image.RotateFlip(RotateFlipType.RotateNoneFlipX);
            pictureBox1.Refresh();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            AktualizujCene();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            AktualizujCene();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            AktualizujCene();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            AktualizujCene();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            AktualizujCene();
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            AktualizujCene();
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {
            AktualizujCene();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            AktualizujCene();
        }


        private decimal ObliczCene(bool ulgowy, string czas)
        {
            decimal cena = 0;

            switch (czas)
            {
                case "1h": cena = 40; break;
                case "2h": cena = 60; break;
                case "4h": cena = 90; break;
                case "całodniowy": cena = 130; break;
                case "tygodniowy": cena = 400; break;
            }

            if (ulgowy)
                cena /= 2;

            return cena;
        }



        private void AktualizujCene()
        {
            // 1. Rodzaj biletu
            bool ulgowy = ULGOWY.Checked;

            // 2. Czas trwania (ustal, która opcja jest zaznaczona)
            string czas = "";
            if (radioButton3.Checked) czas = "1h";
            else if (radioButton4.Checked) czas = "2h";
            else if (radioButton5.Checked) czas = "4h";
            else if (radioButton1.Checked) czas = "całodniowy";
            else if (radioButton6.Checked) czas = "tygodniowy";

            // 3. Oblicz cenę
            decimal cena = ObliczCene(ulgowy, czas);

            // 4. Wyświetl wynik, np. w Labelu

            int ilosc = (int)numericUpDown1.Value;

            decimal cenaCalkowita = cena * ilosc;

            textBox5.Text = $"Cena: {cenaCalkowita} zł";

            button1.Enabled = cenaCalkowita > 0;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            PlatnoscForm platnosc = new PlatnoscForm(form1Ref);
            platnosc.ShowDialog();
        }


        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }


}
