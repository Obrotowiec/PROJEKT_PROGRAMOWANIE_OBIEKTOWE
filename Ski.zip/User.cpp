#include "User.h"
#include <iostream>

User::User(const std::string& name, int id)
    : name(name), id(id) {}

void User::addPass(const SkiPass& pass) {
    passes.push_back(pass);
}

void User::showPasses() const {
    if (passes.empty()) {
        std::cout << "Nie masz zadnych karnetow.\n";
        return;
    }
    for (size_t i = 0; i < passes.size(); ++i) {
        const SkiPass& p = passes[i];
        std::cout << (i + 1) << ". Typ: " << p.getType()
                  << (p.isDiscounted() ? " (ulgowy)" : " (normalny)")
                  << ", wazny do: " << p.getExpiryTimeStr()
                  << (p.isValid() ? " [aktywny]" : " [wygasly]") << "\n";
    }
}

std::vector<SkiPass>& User::getPasses() {
    return passes;
}
