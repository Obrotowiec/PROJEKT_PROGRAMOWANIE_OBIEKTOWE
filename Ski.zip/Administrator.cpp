#include "Administrator.h"
#include <algorithm>

Administrator::Administrator() {
    // Domyślne typy karnetów
    skiPassTypes = {
        "godzinny",
        "dwugodzinny",
        "czterogodzinny",
        "calodniowy",
        "tygodniowy"
    };
}

void Administrator::addSkiPassType(const std::string& type) {
    if (std::find(skiPassTypes.begin(), skiPassTypes.end(), type) == skiPassTypes.end()) {
        skiPassTypes.push_back(type);
    }
}

bool Administrator::removeSkiPassType(const std::string& type) {
    auto it = std::find(skiPassTypes.begin(), skiPassTypes.end(), type);
    if (it != skiPassTypes.end()) {
        skiPassTypes.erase(it);
        return true;
    }
    return false;
}

const std::vector<std::string>& Administrator::getSkiPassTypes() const {
    return skiPassTypes;
}
