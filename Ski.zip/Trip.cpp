#include "Trip.h"
#include <iostream>

void Trip::makeTrip(User& user, const SkiLift& lift, const std::string& passType) {
    auto& passes = user.getPasses();
    bool validPassFound = false;

    for (auto& pass : passes) {
        if (pass.getType() == passType && pass.isValid()) {
            validPassFound = true;
            std::cout << "Skorzystano z wyciagu '" << lift.getName()
                      << "' (dlugosc: " << lift.getLength() << "m, kolor: " << lift.getColor() << ")\n";
            return;
        }
    }

    if (!validPassFound) {
        std::cout << "Nie masz waznego karnetu typu '" << passType << "' do skorzystania z wyciagu.\n";
    }
}
