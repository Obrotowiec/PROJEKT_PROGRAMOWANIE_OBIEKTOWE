#include "SkiLift.h"

SkiLift::SkiLift() : name(""), length(0), color("") {}

SkiLift::SkiLift(const std::string& name, int length, const std::string& color)
    : name(name), length(length), color(color) {}

std::string SkiLift::getName() const {
    return name;
}

int SkiLift::getLength() const {
    return length;
}

std::string SkiLift::getColor() const {
    return color;
}
