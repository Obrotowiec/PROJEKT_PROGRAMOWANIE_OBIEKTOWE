#include <iostream>
#include <string>
#include <map>
#include "User.h"
#include "SkiLift.h"
#include "Trip.h"
#include "Administrator.h"

void clearInputBuffer() {
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

std::string getLine(const std::string& prompt) {
    std::cout << prompt;
    std::string line;
    std::getline(std::cin, line);
    return line;
}

std::string getAdminPassword() {
    std::string password;
    std::cout << "Podaj haslo administratora: ";
    std::getline(std::cin, password);
    return password;
}

int main() {
    Administrator admin;
    std::map<std::string, int> passDurations = {
        {"godzinny", 60},
        {"dwugodzinny", 120},
        {"czterogodzinny", 240},
        {"calodniowy", 1440},
        {"tygodniowy", 10080}
    };

    std::map<std::string, int> passPrices = {
        {"godzinny", 40},
        {"dwugodzinny", 60},
        {"czterogodzinny", 90},
        {"calodniowy", 130},
        {"tygodniowy", 400}
    };

    std::map<std::string, SkiLift> skiLifts;

    std::string userName;
    int userId;

    std::cout << "Podaj swoje imie: ";
    std::getline(std::cin, userName);

    std::cout << "Podaj swoj ID: ";
    while (!(std::cin >> userId)) {
        std::cout << "Niepoprawny ID, podaj liczbe: ";
        std::cin.clear();
        clearInputBuffer();
    }
    clearInputBuffer();

    User user(userName, userId);

    int choice;

    do {
        std::cout << "\n=== MENU ===\n";
        std::cout << "1. Dodaj karnet\n";
        std::cout << "2. Wyswietl karnety\n";
        std::cout << "3. Skorzystaj z wyciagu\n";
        std::cout << "4. Wydluz karnet\n";
        std::cout << "5. Panel administratora\n";
        std::cout << "6. Wyjdz\n";
        std::cout << "Wybierz opcje: ";

        if (!(std::cin >> choice)) {
            std::cout << "Niepoprawny wybor! Sprobuj ponownie.\n";
            std::cin.clear();
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        switch (choice) {
            case 1: {
                std::cout << "Dostepne typy karnetow:\n";
                const auto& types = admin.getSkiPassTypes();
                for (size_t i = 0; i < types.size(); ++i) {
                    std::string type = types[i];
                    int price = passPrices.count(type) ? passPrices[type] : 0;
                    std::cout << (i+1) << ". " << type << " (cena: " << price << " zl)\n";
                }
                std::cout << "Twoj wybor: ";
                int passTypeChoice;
                if (!(std::cin >> passTypeChoice) || passTypeChoice < 1 || passTypeChoice > (int)types.size()) {
                    std::cout << "Niepoprawny wybor.\n";
                    std::cin.clear();
                    clearInputBuffer();
                    break;
                }
                clearInputBuffer();

                std::string selectedType = types[passTypeChoice - 1];
                char discountChoice;
                std::cout << "Czy karnet jest ulgowy? (t/n): ";
                std::cin >> discountChoice;
                std::cin.ignore();

                bool isDiscounted = (discountChoice == 't' || discountChoice == 'T');
                int price = passPrices.count(selectedType) ? passPrices[selectedType] : 0;
                if (isDiscounted) {
                    price /= 2;
                }

                SkiPass newPass(selectedType, passDurations[selectedType], isDiscounted, price);
                user.addPass(newPass);

                std::cout << "Dodano karnet: " << selectedType
                          << (isDiscounted ? " (ulgowy)" : " (normalny)")
                          << ", cena: " << price << " zl\n";
                break;
            }

            case 2:
                user.showPasses();
                break;

            case 3: {
                std::string liftName = getLine("Podaj nazwe wyciagu: ");

                auto it = skiLifts.find(liftName);
                if (it == skiLifts.end()) {
                    std::cout << "Nie znaleziono wyciagu o nazwie: " << liftName << "\n";
                    break;
                }

                std::string passType = getLine("Podaj typ karnetu do uzycia (np. godzinny): ");
                Trip::makeTrip(user, it->second, passType);
                break;
            }

            case 4: {
                auto& passes = user.getPasses();
                if (passes.empty()) {
                    std::cout << "Nie masz zadnych karnetow do wydluzenia.\n";
                    break;
                }

                std::cout << "Twoje karnety:\n";
                for (size_t i = 0; i < passes.size(); i++) {
                    std::cout << (i + 1) << ". " << passes[i].getType()
                              << (passes[i].isDiscounted() ? " (ulgowy)" : " (normalny)")
                              << ", wazny do: " << passes[i].getExpiryTimeStr()
                              << (passes[i].isValid() ? " [aktywny]" : " [wygasly]") << "\n";
                }

                std::cout << "Podaj numer karnetu do wydluzenia: ";
                int passIndex;
                if (!(std::cin >> passIndex) || passIndex < 1 || passIndex > (int)passes.size()) {
                    std::cout << "Niepoprawny numer karnetu.\n";
                    std::cin.clear();
                    clearInputBuffer();
                    break;
                }
                clearInputBuffer();

                std::cout << "Podaj ile minut chcesz dodac: ";
                int extraMinutes;
                if (!(std::cin >> extraMinutes) || extraMinutes <= 0) {
                    std::cout << "Niepoprawna liczba minut.\n";
                    std::cin.clear();
                    clearInputBuffer();
                    break;
                }
                clearInputBuffer();

                int costPerMinute = 1;
                int totalCost = costPerMinute * extraMinutes;

                std::cout << "Przedluzenie karnetu kosztuje " << totalCost << " zl. Potwierdzasz? (t/n): ";
                char confirm;
                std::cin >> confirm;
                std::cin.ignore();

                if (confirm == 't' || confirm == 'T') {
                    passes[passIndex - 1].extend(extraMinutes);
                    std::cout << "Wydluzono karnet o " << extraMinutes << " minut za " << totalCost << " zl.\n";
                } else {
                    std::cout << "Anulowano przedluzanie karnetu.\n";
                }

                break;
            }

            case 5: {
                std::string password = getAdminPassword();

                if (password != "admin123") {
                    std::cout << "Niepoprawne haslo. Nie zalogowano.\n";
                    break;
                }

                std::cout << "Zalogowano jako administrator.\n";

                int adminChoice;
                do {
                    std::cout << "\n=== ADMINISTRATOR ===\n";
                    std::cout << "1. Dodaj typ karnetu\n";
                    std::cout << "2. Usun typ karnetu\n";
                    std::cout << "3. Pokaz typy karnetow\n";
                    std::cout << "4. Dodaj wyciag\n";
                    std::cout << "5. Usun wyciag\n";
                    std::cout << "6. Pokaz wyciagi\n";
                    std::cout << "7. Wyjdz do glownego menu\n";
                    std::cout << "Wybierz opcje: ";

                    if (!(std::cin >> adminChoice)) {
                        std::cout << "Niepoprawny wybor\n";
                        std::cin.clear();
                        clearInputBuffer();
                        continue;
                    }
                    clearInputBuffer();

                    switch (adminChoice) {
                        case 1: {
                            std::string newType = getLine("Podaj nazwe nowego typu karnetu: ");
                            int duration;
                            std::cout << "Podaj czas trwania karnetu w minutach: ";
                            while (!(std::cin >> duration) || duration <= 0) {
                                std::cout << "Niepoprawny czas trwania. Podaj wartosc dodatnia: ";
                                std::cin.clear();
                                clearInputBuffer();
                            }
                            clearInputBuffer();

                            int price;
                            std::cout << "Podaj cene karnetu: ";
                            while (!(std::cin >> price) || price <= 0) {
                                std::cout << "Niepoprawna cena. Podaj wartosc dodatnia: ";
                                std::cin.clear();
                                clearInputBuffer();
                            }
                            clearInputBuffer();

                            admin.addSkiPassType(newType);
                            passDurations[newType] = duration;
                            passPrices[newType] = price;

                            std::cout << "Dodano nowy typ karnetu: " << newType
                                      << " (czas: " << duration << " min, cena: " << price << " zl)\n";
                            break;
                        }
                        case 2: {
                            std::string typeToRemove = getLine("Podaj typ karnetu do usuniecia: ");
                            if (admin.removeSkiPassType(typeToRemove)) {
                                passDurations.erase(typeToRemove);
                                passPrices.erase(typeToRemove);
                                std::cout << "Usunieto typ karnetu: " << typeToRemove << "\n";
                            } else {
                                std::cout << "Nie znaleziono takiego typu.\n";
                            }
                            break;
                        }
                        case 3: {
                            const auto& types = admin.getSkiPassTypes();
                            std::cout << "Dostepne typy karnetow:\n";
                            for (const auto& t : types) {
                                int price = passPrices.count(t) ? passPrices[t] : 0;
                                int dur = passDurations.count(t) ? passDurations[t] : 0;
                                std::cout << "- " << t << " (czas: " << dur << " min, cena: " << price << " zl)\n";
                            }
                            break;
                        }
                        case 4: {
                            std::string liftName = getLine("Podaj nazwe nowego wyciagu: ");
                            int length;
                            std::cout << "Podaj dlugosc trasy w metrach: ";
                            while (!(std::cin >> length) || length <= 0) {
                                std::cout << "Niepoprawna dlugosc. Podaj wartosc dodatnia: ";
                                std::cin.clear();
                                clearInputBuffer();
                            }
                            clearInputBuffer();

                            std::string color = getLine("Podaj kolor wyciagu: ");
                            SkiLift newLift(liftName, length, color);
                            skiLifts[liftName] = newLift;

                            std::cout << "Dodano nowy wyciag: " << liftName
                                      << " (dlugosc: " << length << " m, kolor: " << color << ")\n";
                            break;
                        }
                        case 5: {
                            std::string liftToRemove = getLine("Podaj nazwe wyciagu do usuniecia: ");
                            if (skiLifts.erase(liftToRemove)) {
                                std::cout << "Usunieto wyciag: " << liftToRemove << "\n";
                            } else {
                                std::cout << "Nie znaleziono wyciagu o takiej nazwie.\n";
                            }
                            break;
                        }
                        case 6: {
                            std::cout << "Dostepne wyciagi:\n";
                            if (skiLifts.empty()) {
                                std::cout << "Brak wyciagow.\n";
                            } else {
                                for (const auto& [name, lift] : skiLifts) {
                                    std::cout << "- " << name << " (dlugosc: " << lift.getLength()
                                              << " m, kolor: " << lift.getColor() << ")\n";
                                }
                            }
                            break;
                        }
                        case 7:
                            std::cout << "Powrot do glownego menu.\n";
                            break;
                        default:
                            std::cout << "Niepoprawny wybor.\n";
                            break;
                    }

                } while (adminChoice != 7);
                break;
            }

            case 6:
                std::cout << "Koniec programu.\n";
                break;

            default:
                std::cout << "Niepoprawny wybor.\n";
                break;
        }

    } while (choice != 6);

    return 0;
}
