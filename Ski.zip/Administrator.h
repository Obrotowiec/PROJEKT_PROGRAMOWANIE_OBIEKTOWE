#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H

#include <vector>
#include <string>

class Administrator {
private:
    std::vector<std::string> skiPassTypes;

public:
    Administrator();

    void addSkiPassType(const std::string& type);
    bool removeSkiPassType(const std::string& type);
    const std::vector<std::string>& getSkiPassTypes() const;
};

#endif
