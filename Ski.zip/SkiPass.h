#ifndef SKIPASS_H
#define SKIPASS_H

#include <string>
#include <ctime>

class SkiPass {
private:
    std::string type;
    int durationMinutes;
    bool discounted;
    int price;
    std::time_t expiryTime;

public:
    SkiPass(const std::string& type, int durationMinutes, bool discounted, int price);

    bool isValid() const;
    void extend(int extraMinutes);

    std::string getType() const;
    bool isDiscounted() const;
    int getPrice() const;

    std::string getExpiryTimeStr() const;
};

#endif
