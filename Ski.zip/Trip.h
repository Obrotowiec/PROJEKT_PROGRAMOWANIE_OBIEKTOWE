#ifndef TRIP_H
#define TRIP_H

#include "User.h"
#include "SkiLift.h"
#include <string>

class Trip {
public:
    static void makeTrip(User& user, const SkiLift& lift, const std::string& passType);
};

#endif
