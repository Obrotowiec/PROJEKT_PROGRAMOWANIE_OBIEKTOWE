#ifndef SKILIFT_H
#define SKILIFT_H

#include <string>

class SkiLift {
private:
    std::string name;
    int length;     // w metrach
    std::string color;

public:
    SkiLift();
    SkiLift(const std::string& name, int length, const std::string& color);

    std::string getName() const;
    int getLength() const;
    std::string getColor() const;
};

#endif
