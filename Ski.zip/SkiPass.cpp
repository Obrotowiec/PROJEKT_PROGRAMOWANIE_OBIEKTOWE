#include "SkiPass.h"
#include <ctime>
#include <iomanip>
#include <sstream>

SkiPass::SkiPass(const std::string& type, int durationMinutes, bool discounted, int price)
    : type(type), durationMinutes(durationMinutes), discounted(discounted), price(price) 
{
    expiryTime = std::time(nullptr) + durationMinutes * 60;
}

bool SkiPass::isValid() const {
    std::time_t now = std::time(nullptr);
    return now < expiryTime;
}

void SkiPass::extend(int extraMinutes) {
    expiryTime += extraMinutes * 60;
}

std::string SkiPass::getType() const {
    return type;
}

bool SkiPass::isDiscounted() const {
    return discounted;
}

int SkiPass::getPrice() const {
    return price;
}

std::string SkiPass::getExpiryTimeStr() const {
    std::tm* tm_ptr = std::localtime(&expiryTime);
    std::ostringstream oss;
    oss << std::put_time(tm_ptr, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}
