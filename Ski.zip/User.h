#ifndef USER_H
#define USER_H

#include <string>
#include <vector>
#include "SkiPass.h"

class User {
private:
    std::string name;
    int id;
    std::vector<SkiPass> passes;

public:
    User(const std::string& name, int id);

    void addPass(const SkiPass& pass);
    void showPasses() const;

    std::vector<SkiPass>& getPasses();
};

#endif
