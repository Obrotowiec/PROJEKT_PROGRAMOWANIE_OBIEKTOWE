#ifndef SKIPASS_H
#define SKIPASS_H

#include <string>
#include <chrono>
#include <ctime>

class SkiPass {
private:
    std::string type;
    bool discounted;
    int price;  // cena karnetu
    std::chrono::system_clock::time_point expiryTime;

public:
    SkiPass(const std::string& type, int durationMinutes, bool discounted, int price);

    std::string getType() const;
    bool isDiscounted() const;
    int getPrice() const;

    bool isValid() const;
    std::string getExpiryTimeStr() const;

    void extend(int extraMinutes);
};

#endif
