#ifndef SKILIFT_H
#define SKILIFT_H

#include <string>

class SkiLift {
private:
    std::string name;

public:
    SkiLift(const std::string& name);
    std::string getName() const;
};

#endif
