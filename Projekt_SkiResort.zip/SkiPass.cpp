#include "SkiPass.h"
#include <iomanip>
#include <sstream>

SkiPass::SkiPass(const std::string& type, int durationMinutes, bool discounted, int price)
    : type(type), discounted(discounted), price(price) {
    expiryTime = std::chrono::system_clock::now() + std::chrono::minutes(durationMinutes);
}

std::string SkiPass::getType() const {
    return type;
}

bool SkiPass::isDiscounted() const {
    return discounted;
}

int SkiPass::getPrice() const {
    return price;
}

bool SkiPass::isValid() const {
    return std::chrono::system_clock::now() < expiryTime;
}

std::string SkiPass::getExpiryTimeStr() const {
    std::time_t tt = std::chrono::system_clock::to_time_t(expiryTime);
    std::tm tm = *std::localtime(&tt);

    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d %H:%M");
    return oss.str();
}

void SkiPass::extend(int extraMinutes) {
    expiryTime += std::chrono::minutes(extraMinutes);
}
