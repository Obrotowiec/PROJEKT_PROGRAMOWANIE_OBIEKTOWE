#include "Trip.h"
#include <iostream>

void Trip::makeTrip(User& user, SkiLift& lift, const std::string& passType) {
    std::cout << "Uzytkownik korzysta z wyciagu: " << lift.getName() << "\n";
    if (user.useLift(passType)) {
        std::cout << "Wyjazd zaliczony\n";
    } else {
        std::cout << "Wyjazd niezaliczony\n";
    }
}
