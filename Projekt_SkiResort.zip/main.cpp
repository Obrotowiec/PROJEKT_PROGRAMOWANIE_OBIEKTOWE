#include <iostream>
#include <vector>
#include <map>
#include <limits>
#include "User.h"
#include "SkiLift.h"
#include "Trip.h"

void clearInputBuffer() {
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

std::string getLine(const std::string& prompt) {
    std::cout << prompt;
    std::string line;
    std::getline(std::cin, line);
    return line;
}

int main() {
    std::string userName;
    int userId;

    std::cout << "Podaj swoje imie: ";
    std::getline(std::cin, userName);

    std::cout << "Podaj swoj ID: ";
    while (!(std::cin >> userId)) {
        std::cout << "Niepoprawny ID, podaj liczbe: ";
        std::cin.clear();
        clearInputBuffer();
    }
    clearInputBuffer();

    User user(userName, userId);

    std::map<int, std::string> passOptions = {
        {1, "godzinny"},
        {2, "dwugodzinny"},
        {3, "czterogodzinny"},
        {4, "calodniowy"},
        {5, "tygodniowy"}
    };

    std::map<std::string, int> passDurations = {
        {"godzinny", 60},
        {"dwugodzinny", 120},
        {"czterogodzinny", 240},
        {"calodniowy", 1440},
        {"tygodniowy", 10080}
    };

    std::map<std::string, int> passPrices = {
        {"godzinny", 40},
        {"dwugodzinny", 60},
        {"czterogodzinny", 90},
        {"calodniowy", 130},
        {"tygodniowy", 400}
    };

    int choice;

    do {
        std::cout << "\n=== MENU ===\n";
        std::cout << "1. Dodaj karnet\n";
        std::cout << "2. Wyswietl karnety\n";
        std::cout << "3. Skorzystaj z wyciagu\n";
        std::cout << "4. Wydluz karnet\n";
        std::cout << "5. Wyjdz\n";
        std::cout << "Wybierz opcje: ";

        if (!(std::cin >> choice)) {
            std::cout << "Niepoprawny wybor! Sprobuj ponownie.\n";
            std::cin.clear();
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        switch (choice) {
            case 1: {
                std::cout << "Wybierz typ karnetu:\n";
                for (const auto& option : passOptions) {
                    std::cout << option.first << ". " << option.second
                              << " (cena: " << passPrices[option.second] << " zl)\n";
                }

                int passTypeChoice;
                std::cout << "Twoj wybor: ";
                if (!(std::cin >> passTypeChoice)) {
                    std::cout << "Niepoprawny wybor.\n";
                    std::cin.clear();
                    clearInputBuffer();
                    break;
                }
                clearInputBuffer();

                if (passOptions.find(passTypeChoice) == passOptions.end()) {
                    std::cout << "Niepoprawny wybor.\n";
                    break;
                }

                std::string selectedType = passOptions[passTypeChoice];

                char discountChoice;
                std::cout << "Czy karnet jest ulgowy? (t/n): ";
                std::cin >> discountChoice;
                std::cin.ignore();

                bool isDiscounted = (discountChoice == 't' || discountChoice == 'T');

                int price = passPrices[selectedType];
                if (isDiscounted) {
                    price = price / 2; 
                }

                SkiPass newPass(selectedType, passDurations[selectedType], isDiscounted, price);
                user.addPass(newPass);

                std::cout << "Dodano karnet: " << selectedType
                          << (isDiscounted ? " (ulgowy)" : " (normalny)")
                          << ", cena: " << price << " zl\n";
                break;
            }

            case 2:
                user.showPasses();
                break;

            case 3: {
                std::string liftName = getLine("Podaj nazwe wyciagu: ");

                SkiLift lift(liftName);

                std::string passType = getLine("Podaj typ karnetu do uzycia (np. godzinny): ");

                Trip::makeTrip(user, lift, passType);
                break;
            }

            case 4: {
                auto& passes = user.getPasses();
                if (passes.empty()) {
                    std::cout << "Nie masz żadnych karnetów do wydłużenia.\n";
                    break;
                }

                std::cout << "Twoje karnety:\n";
                for (size_t i = 0; i < passes.size(); i++) {
                    std::cout << (i + 1) << ". " << passes[i].getType()
                              << (passes[i].isDiscounted() ? " (ulgowy)" : " (normalny)")
                              << ", wazny do: " << passes[i].getExpiryTimeStr()
                              << (passes[i].isValid() ? " [aktywny]" : " [wygasly]")
                              << "\n";
                }

                std::cout << "Podaj numer karnetu do wydłużenia: ";
                int passIndex;
                if (!(std::cin >> passIndex) || passIndex < 1 || passIndex > (int)passes.size()) {
                    std::cout << "Niepoprawny numer karnetu.\n";
                    std::cin.clear();
                    clearInputBuffer();
                    break;
                }
                clearInputBuffer();

                std::cout << "Podaj ile minut chcesz dodac: ";
                int extraMinutes;
                if (!(std::cin >> extraMinutes) || extraMinutes <= 0) {
                    std::cout << "Niepoprawna liczba minut.\n";
                    std::cin.clear();
                    clearInputBuffer();
                    break;
                }
                clearInputBuffer();

                passes[passIndex - 1].extend(extraMinutes);
                std::cout << "Wydłużono karnet o " << extraMinutes << " minut.\n";

                break;
            }

            case 5:
                std::cout << "Zamykanie programu...\n";
                break;

            default:
                std::cout << "Nieprawidlowy wybor.\n";
                break;
        }

    } while (choice != 5);

    return 0;
}
