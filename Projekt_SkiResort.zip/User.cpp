#include "User.h"
#include <iostream>

User::User(const std::string& name, int id) : name(name), id(id) {}

void User::addPass(const SkiPass& pass) {
    passes.push_back(pass);
}

void User::showPasses() const {
    std::cout << "Karnety uzytkownika " << name << ":\n";
    if (passes.empty()) {
        std::cout << "Brak karnetow.\n";
        return;
    }
    for (const auto& pass : passes) {
        std::cout << "- Typ: " << pass.getType()
                  << (pass.isDiscounted() ? " (ulgowy)" : " (normalny)")
                  << ", cena: " << pass.getPrice() << " zl"
                  << ", wazny do: " << pass.getExpiryTimeStr()
                  << (pass.isValid() ? " [aktywny]" : " [wygasly]")
                  << "\n";
    }
}

bool User::useLift(const std::string& passType) {
    for (auto& pass : passes) {
        if (pass.getType() == passType && pass.isValid()) {
            std::cout << "Karnet " << passType << " jest aktywny. Wjazd zaliczony.\n";
            return true;
        }
    }
    std::cout << "Brak aktywnego karnetu typu: " << passType << "\n";
    return false;
}

std::vector<SkiPass>& User::getPasses() {
    return passes;
}
