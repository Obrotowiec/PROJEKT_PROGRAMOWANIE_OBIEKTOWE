#include "SkiLift.h"

SkiLift::SkiLift(const std::string& name) : name(name) {}

std::string SkiLift::getName() const {
    return name;
}
